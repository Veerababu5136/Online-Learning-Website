
function validate()

{

    // Get the email and password values from the form
    var email = document.getElementById("email").value;
    var password = document.getElementById("password").value;

    alert(email+password);

   

}